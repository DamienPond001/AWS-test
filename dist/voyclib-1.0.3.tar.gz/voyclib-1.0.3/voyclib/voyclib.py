def test():
    print('This are test')